package com.example.microservicioVehiculo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioVehiculoApplicationTests {

	@Test
	void contextLoads() {
	}

}
