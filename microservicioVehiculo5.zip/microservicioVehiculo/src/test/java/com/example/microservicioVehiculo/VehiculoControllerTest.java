package com.example.microservicioVehiculo;

import com.example.microservicioVehiculo.controller.VehiculoController;
import com.example.microservicioVehiculo.model.Vehiculo;
import com.example.microservicioVehiculo.service.VehiculoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class VehiculoControllerTest {

    @Mock
    private VehiculoService service;

    @InjectMocks
    private VehiculoController controller;

    @Test
    void deberiaCrearVehiculo() {

        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setId(1L);

        when(service.crear(any(Vehiculo.class)))
                .thenReturn(vehiculo);

        ResponseEntity<Vehiculo> respuesta =
                controller.crear(vehiculo);

        assertEquals(HttpStatus.CREATED,
                respuesta.getStatusCode());

        assertNotNull(respuesta.getBody());

        assertEquals(1L,
                respuesta.getBody().getId());

        verify(service).crear(vehiculo);
    }

    @Test
    void deberiaListarVehiculos() {

        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setId(1L);

        when(service.listar())
                .thenReturn(List.of(vehiculo));

        ResponseEntity<List<Vehiculo>> respuesta =
                controller.listar();

        assertEquals(HttpStatus.OK,
                respuesta.getStatusCode());

        assertEquals(1,
                respuesta.getBody().size());

        verify(service).listar();
    }

    @Test
    void deberiaObtenerVehiculoPorId() {

        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setId(1L);

        when(service.obtener(1L))
                .thenReturn(vehiculo);

        ResponseEntity<Vehiculo> respuesta =
                controller.obtener(1L);

        assertEquals(HttpStatus.OK,
                respuesta.getStatusCode());

        assertNotNull(respuesta.getBody());

        assertEquals(1L,
                respuesta.getBody().getId());

        verify(service).obtener(1L);
    }
}
