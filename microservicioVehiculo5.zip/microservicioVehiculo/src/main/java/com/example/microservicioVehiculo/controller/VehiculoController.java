package com.example.microservicioVehiculo.controller;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.microservicioVehiculo.model.Vehiculo;
import com.example.microservicioVehiculo.service.VehiculoService;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vehiculos")
@RequiredArgsConstructor
public class VehiculoController {

    private final VehiculoService service;

    @PostMapping
    public ResponseEntity<Vehiculo> crear(@Valid @RequestBody Vehiculo
                                                 vehiculo) {
        Vehiculo vec = service.crear(vehiculo);
        vec.add(linkTo(methodOn(VehiculoController.class).listar()).withRel
                ("todos"));
        vec.add(linkTo(methodOn(VehiculoController.class).obtener(vehiculo.getId())).withSelfRel());
        vec.add(linkTo(methodOn(VehiculoController.class).actualizar(vec.getId(),vehiculo)).withRel("update"));
        vec.add(linkTo(methodOn(VehiculoController.class).eliminar(vec.getId())).withRel("delete"));
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(vec);
    }

    @GetMapping
    public ResponseEntity<List<Vehiculo>> listar() {
        List<Vehiculo> lista = service.listar();

        lista.forEach(v -> {
            v.add(linkTo(methodOn(VehiculoController.class)
                    .obtener(v.getId()))
                    .withSelfRel());

            v.add(linkTo(methodOn(VehiculoController.class)
                    .actualizar(v.getId(), null))
                    .withRel("update"));

            v.add(linkTo(methodOn(VehiculoController.class)
                    .eliminar(v.getId()))
                    .withRel("delete"));
        });

        return ResponseEntity.ok(lista);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Vehiculo> obtener(@PathVariable Long id) {

        Vehiculo vehiculo = service.obtener(id);

        vehiculo.add(linkTo(methodOn(VehiculoController.class)
                .obtener(id))
                .withSelfRel());

        vehiculo.add(linkTo(methodOn(VehiculoController.class)
                .listar())
                .withRel("todos"));

        vehiculo.add(linkTo(methodOn(VehiculoController.class)
                .actualizar(id, null))
                .withRel("update"));

        vehiculo.add(linkTo(methodOn(VehiculoController.class)
                .eliminar(id))
                .withRel("delete"));

        return ResponseEntity.ok(vehiculo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Vehiculo> actualizar(
            @PathVariable Long id,
            @RequestBody Vehiculo vehiculo) {

        Vehiculo actualizado = service.actualizar(id, vehiculo);

        actualizado.add(linkTo(methodOn(VehiculoController.class)
                .obtener(id))
                .withSelfRel());

        actualizado.add(linkTo(methodOn(VehiculoController.class)
                .listar())
                .withRel("todos"));

        actualizado.add(linkTo(methodOn(VehiculoController.class)
                .eliminar(id))
                .withRel("delete"));

        return ResponseEntity.ok(actualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/reducir-stock")
    public ResponseEntity<Vehiculo> reducirStock(@PathVariable Long id) {

        Vehiculo vehiculo = service.reducirStock(id);

        vehiculo.add(linkTo(methodOn(VehiculoController.class)
                .obtener(id))
                .withSelfRel());

        vehiculo.add(linkTo(methodOn(VehiculoController.class)
                .listar())
                .withRel("todos"));

        return ResponseEntity.ok(vehiculo);
    }
}