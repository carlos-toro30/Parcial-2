package com.example.microservicioVehiculo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioVehiculoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioVehiculoApplication.class, args);
	}

}
