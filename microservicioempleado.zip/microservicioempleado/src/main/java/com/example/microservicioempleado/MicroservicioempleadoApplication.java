package com.example.microservicioempleado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class MicroservicioempleadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioempleadoApplication.class, args);
	}

}
