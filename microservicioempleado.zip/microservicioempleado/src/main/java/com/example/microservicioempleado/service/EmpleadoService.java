package com.example.microservicioempleado.service;

import com.example.microservicioempleado.client.SucursalClient;
import com.example.microservicioempleado.model.Empleado;
import com.example.microservicioempleado.repository.EmpleadoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmpleadoService {

    private final EmpleadoRepository repo;
    private final SucursalClient sucursalClient;

    // 🔥 CREAR
    public Empleado crear(Empleado e) {
        if (e.getSucursalId() == null) {
            throw new RuntimeException("Debe enviar sucursalId");
        }

        sucursalClient.obtenerSucursal(e.getSucursalId());
        return repo.save(e);
    }

    // 🔥 LISTAR TODOS
    public List<Empleado> listar() {
        return repo.findAll();
    }

    // 🔥 OBTENER POR ID
    public Empleado obtener(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Empleado no encontrado"));
    }

    // 🔥 ACTUALIZAR
    public Empleado actualizar(Long id, Empleado nuevo) {

        Empleado existente = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Empleado no encontrado"));

        // validar sucursal si viene
        if (nuevo.getSucursalId() != null) {
            sucursalClient.obtenerSucursal(nuevo.getSucursalId());
            existente.setSucursalId(nuevo.getSucursalId());
        }

        existente.setNombre(nuevo.getNombre());
        existente.setCorreo(nuevo.getCorreo());
        existente.setRol(nuevo.getRol());

        return repo.save(existente);
    }

    // 🔥 ELIMINAR
    public void eliminar(Long id) {

        if (!repo.existsById(id)) {
            throw new RuntimeException("Empleado no encontrado");
        }

        repo.deleteById(id);
    }
}