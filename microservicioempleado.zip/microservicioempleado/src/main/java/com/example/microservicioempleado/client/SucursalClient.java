package com.example.microservicioempleado.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(
    name = "sucursal",
    url = "http://localhost:9094",
    configuration = com.example.microservicioempleado.config.FeignConfig.class
)
public interface SucursalClient {

    @GetMapping("/sucursales/{id}")
    Object obtenerSucursal(@PathVariable Long id);
}