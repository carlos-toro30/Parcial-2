package com.example.microservicioempleado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioempleadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
