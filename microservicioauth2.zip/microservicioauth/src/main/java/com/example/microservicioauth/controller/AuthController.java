package com.example.microservicioauth.controller;



import com.example.microservicioauth.model.Usuario;
import com.example.microservicioauth.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService service;

    @PostMapping("/register")
    public Usuario register(@RequestBody Usuario user) {
        return service.registrar(user);
    }

    @PostMapping("/login")
    public String login(@RequestBody Map<String, String> request) {

        String username = request.get("username");
        String password = request.get("password");

        return service.login(username, password);
    }
}