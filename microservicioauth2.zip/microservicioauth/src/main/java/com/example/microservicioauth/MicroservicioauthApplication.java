package com.example.microservicioauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioauthApplication.class, args);
	}

}
