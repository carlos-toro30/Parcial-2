package com.example.microservicioauth.service;


import com.example.microservicioauth.model.Usuario;
import com.example.microservicioauth.repository.UsuarioRepository;
import com.example.microservicioauth.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class    AuthService {

    private final UsuarioRepository repository;
    private final JwtUtil jwtUtil;

    public String login(String username, String password) {

        Usuario user = repository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Usuario no existe"));

        if (!user.getPassword().equals(password)) {
            throw new RuntimeException("Contraseña incorrecta");
        }

        return jwtUtil.generarToken(username);
    }

    public Usuario registrar(Usuario user) {
        return repository.save(user);
    }
}