package com.example.microservicioVehiculo;


public class VehiculoServiceTest {
}
