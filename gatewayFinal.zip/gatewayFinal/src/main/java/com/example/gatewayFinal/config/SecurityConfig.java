package com.example.gatewayFinal.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

    @Bean
    public SecurityWebFilterChain filterChain(ServerHttpSecurity http) {

        return http
                // 🔥 IMPORTANTE (forma correcta en WebFlux)
                .csrf(csrf -> csrf.disable())

                .authorizeExchange(exchange -> exchange

                        // ✅ RUTAS PÚBLICAS (LOGIN / REGISTER)
                        .pathMatchers("/auth/**").permitAll()

                        // 🔐 TODO LO DEMÁS PROTEGIDO
                        .anyExchange().authenticated()
                )

                .build();
    }
}