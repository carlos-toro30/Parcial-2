package com.example.microservicioVenta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class MicroservicioVentaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioVentaApplication.class, args);
	}

}
