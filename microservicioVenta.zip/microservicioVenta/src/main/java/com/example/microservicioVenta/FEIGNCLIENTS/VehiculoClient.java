package com.example.microservicioVenta.FEIGNCLIENTS;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "vehiculo-service", url = "http://localhost:9095")
public interface VehiculoClient {

    @GetMapping("/vehiculos/{id}")
    Object obtenerVehiculo(@PathVariable Long id);

    @PutMapping("/vehiculos/{id}/reducir-stock")
    void reducirStock(@PathVariable Long id);


}