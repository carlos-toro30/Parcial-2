package com.example.microservicioVenta.FEIGNCLIENTS;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "cliente-service", url = "http://localhost:9092")
public interface ClienteClient {

    @GetMapping("/clientes/{id}")
    Object obtenerCliente(@PathVariable Long id);
}