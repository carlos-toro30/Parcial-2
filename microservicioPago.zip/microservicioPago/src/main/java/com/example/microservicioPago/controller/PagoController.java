package com.example.microservicioPago.controller;

import com.example.microservicioPago.model.Pago;
import com.example.microservicioPago.service.PagoService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pagos")
@RequiredArgsConstructor
public class PagoController {

    private final PagoService service;

    @PostMapping
    public Pago crear(@RequestBody Pago pago) {
        return service.crear(pago);
    }

    @GetMapping
    public List<Pago> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Pago obtener(@PathVariable Long id) {
        return service.obtener(id);
    }
}