package com.example.microservicioPago.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(
        name = "venta-service",
        url = "http://localhost:9093",
        configuration = com.example.microservicioPago.config.FeignConfig.class
)
public interface VentaClient {

    @GetMapping("/ventas/{id}")
    Object obtenerVenta(@PathVariable Long id);
}