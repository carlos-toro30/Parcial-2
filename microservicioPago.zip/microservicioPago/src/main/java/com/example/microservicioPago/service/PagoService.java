package com.example.microservicioPago.service;

import com.example.microservicioPago.feign.VentaClient;
import com.example.microservicioPago.model.Pago;
import com.example.microservicioPago.repository.PagoRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PagoService {

    private final PagoRepository repository;
    private final VentaClient ventaClient;

    public Pago crear(Pago pago) {

        // 🔥 VALIDAR QUE EXISTE LA VENTA
        try {
            ventaClient.obtenerVenta(pago.getVentaId());
        } catch (Exception e) {
            throw new RuntimeException("Venta no existe");
        }

        pago.setFecha(LocalDateTime.now());

        return repository.save(pago);
    }

    public List<Pago> listar() {
        return repository.findAll();
    }

    public Pago obtener(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pago no encontrado"));
    }
}