package com.example.microservicioReporte.service;

import com.example.microservicioReporte.model.Reporte;
import com.example.microservicioReporte.repository.ReporteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReporteService {

    private final ReporteRepository repository;

    public Reporte crear(Reporte reporte) {
        reporte.setFecha(LocalDateTime.now());
        return repository.save(reporte);
    }

    public List<Reporte> listar() {
        return repository.findAll();
    }

    public Reporte obtener(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reporte no encontrado"));
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}