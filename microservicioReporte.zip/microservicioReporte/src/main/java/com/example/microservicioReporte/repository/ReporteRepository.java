package com.example.microservicioReporte.repository;

import com.example.microservicioReporte.model.Reporte;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReporteRepository extends JpaRepository<Reporte, Long> {
}