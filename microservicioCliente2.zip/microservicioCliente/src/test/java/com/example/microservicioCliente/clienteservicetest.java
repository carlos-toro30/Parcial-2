package com.example.microservicioCliente;

public class clienteservicetest {
}
