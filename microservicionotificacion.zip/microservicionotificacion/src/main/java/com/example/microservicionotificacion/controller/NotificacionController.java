package com.example.microservicionotificacion.controller;



import com.example.microservicionotificacion.dto.NotificacionDTO;
import com.example.microservicionotificacion.service.NotificacionService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/notificaciones")
@RequiredArgsConstructor
public class NotificacionController {

    private final NotificacionService service;

    @PostMapping
    public String enviar(@RequestBody NotificacionDTO dto) {
        return service.enviar(dto);
    }
}