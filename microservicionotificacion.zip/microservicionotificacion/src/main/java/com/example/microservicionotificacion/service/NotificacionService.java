package com.example.microservicionotificacion.service;


import com.example.microservicionotificacion.dto.NotificacionDTO;
import org.springframework.stereotype.Service;

@Service
public class NotificacionService {

    public String enviar(NotificacionDTO dto) {

        // Simulación (no envía nada real)
        return "Notificación enviada a " + dto.getDestinatario() +
               " con mensaje: " + dto.getMensaje();
    }
}