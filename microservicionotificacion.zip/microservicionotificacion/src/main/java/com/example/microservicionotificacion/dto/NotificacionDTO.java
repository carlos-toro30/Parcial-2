package com.example.microservicionotificacion.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NotificacionDTO {

    private String mensaje;
    private String destinatario;
}