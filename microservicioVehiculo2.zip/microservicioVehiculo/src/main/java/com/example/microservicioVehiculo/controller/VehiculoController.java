package com.example.microservicioVehiculo.controller;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.microservicioVehiculo.model.Vehiculo;
import com.example.microservicioVehiculo.service.VehiculoService;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vehiculos")
@RequiredArgsConstructor
public class VehiculoController {

    private final VehiculoService service;

    @PostMapping
    public ResponseEntity<Vehiculo> crear(@Valid @RequestBody Vehiculo
                                                 vehiculo) {
        Vehiculo vec = service.crear(vehiculo);
        vec.add(linkTo(methodOn(VehiculoController.class).listar()).withRel
                ("todos"));
        vec.add(linkTo(methodOn(VehiculoController.class).obtener(vehiculo.getId())).withSelfRel());
        vec.add(linkTo(methodOn(VehiculoController.class).actualizar(vec.getId(),vehiculo)).withRel("update"));
        vec.add(linkTo(methodOn(VehiculoController.class).eliminar(vec.getId())).withRel("delete"));
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(vec);
    }

    @GetMapping
    public ResponseEntity<List<Vehiculo>> listar() {
        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Vehiculo> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(service.obtener(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Vehiculo> actualizar(
            @PathVariable Long id,
            @RequestBody Vehiculo vehiculo) {

        return ResponseEntity.ok(service.actualizar(id, vehiculo));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/reducir-stock")
    public void reducirStock(@PathVariable Long id){
        service.reducirStock(id);
    }
}