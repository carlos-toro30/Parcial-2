package com.example.microservicioVehiculo.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "vehiculos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Vehiculo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String marca;
    private String modelo;
    private int anio;

    private double precio;

    private int stock;

    @Column(unique = true)
    private String patente;

    private String estado; // DISPONIBLE, VENDIDO
}