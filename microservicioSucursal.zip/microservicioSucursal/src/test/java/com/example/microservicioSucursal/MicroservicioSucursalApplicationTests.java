package com.example.microservicioSucursal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioSucursalApplicationTests {

	@Test
	void contextLoads() {
	}

}
