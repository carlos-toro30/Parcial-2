package com.example.gatewayFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatewayFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatewayFinalApplication.class, args);
	}

}
