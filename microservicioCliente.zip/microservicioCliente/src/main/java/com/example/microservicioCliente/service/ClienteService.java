package com.example.microservicioCliente.service;

import com.example.microservicioCliente.model.Cliente;
import com.example.microservicioCliente.repository.ClienteRepository;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ClienteService {

    private final ClienteRepository repository;

    public Cliente crear(Cliente cliente) {
        return repository.save(cliente);
    }

    public List<Cliente> listar()  {
        return repository.findAll();
    }

    public Cliente obtener(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
    }

    public Cliente actualizar(Long id, Cliente cliente) {
        Cliente existente = obtener(id);

        existente.setNombre(cliente.getNombre());
        existente.setApellido(cliente.getApellido());
        existente.setCorreo(cliente.getCorreo());
        existente.setTelefono(cliente.getTelefono());
        existente.setDireccion(cliente.getDireccion());

        return repository.save(existente);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}

