package com.example.microservicioCliente.repository;

import com.example.microservicioCliente.model.Cliente;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

}